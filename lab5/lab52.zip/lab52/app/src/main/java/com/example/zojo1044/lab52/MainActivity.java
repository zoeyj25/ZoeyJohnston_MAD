package com.example.zojo1044.lab52;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void findAnimal(View view) {
        //toggle button
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton2);
        boolean location = toggle.isChecked();

        //radio buttons
        RadioButton exercise = (RadioButton) findViewById(R.id.radioButton);
        int exercise_id = exercise.getCheckedRadioButtonId();

        //check boxes
        CheckBox allergiesCheckBox = (CheckBox) findViewById(R.id.checkBox2);
        Boolean allergies = allergiesCheckBox.isChecked();

        CheckBox yardCheckBox = (CheckBox) findViewById(R.id.checkBox3);
        Boolean yard = yardCheckBox.isChecked();

        CheckBox dogCheckBox = (CheckBox) findViewById(R.id.checkBox4);
        Boolean dog = dogCheckBox.isChecked();

        //switch
        Switch homeSwitch = (Switch) findViewById(R.id.switch1);
        boolean home = homeSwitch.isChecked();

        //slider
//        SeekBar groomSeeekbar = (SeekBar) findViewById(R.id.seekBar);
//        int groom = groomSeeekbar




    }
}
