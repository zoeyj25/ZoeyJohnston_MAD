package com.example.zojo1044.afinal;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {


    private void goToUrl (String url) {
        Uri uriUrl = Uri.parse(url);
        Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
        startActivity(launchBrowser);
    }

    public void goToInternet(View view) {
        goToUrl("https://www.google.com/search?q=burrito+places+near+me&oq=burrito+pla&aqs=chrome.0.0l2j69i57j0l3.3046j0j7&sourceid=chrome&ie=UTF-8");
    }

    public void findBurrito(View view) {
        //toggle button
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
        boolean veggie = toggle.isChecked();

        //radio buttons
        RadioGroup type = (RadioGroup) findViewById(R.id.radioGroup);
        int type_id = type.getCheckedRadioButtonId();

        //check boxes
        CheckBox salsaCheckBox = (CheckBox) findViewById(R.id.checkbox);
        Boolean salsa = salsaCheckBox.isChecked();

        CheckBox cheeseCheckBox = (CheckBox) findViewById(R.id.checkBox2);
        Boolean cheese = cheeseCheckBox.isChecked();

        CheckBox sourCheckBox = (CheckBox) findViewById(R.id.checkBox3);
        Boolean sour = sourCheckBox.isChecked();

        CheckBox guacCheckBox = (CheckBox) findViewById(R.id.checkBox4);
        Boolean guac = guacCheckBox.isChecked();

        //pick sport
        String perfectBurrito;

        //check radio buttons
        if (type_id == -1) {
            //toast
            Context context = getApplicationContext();
            CharSequence text = "Please select a cost level";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        } else {
            if (veggie) { //toggle button
                if (type_id == R.id.radioButton) { //veggie option
                    perfectBurrito = "A veggie burrito";
                } else {
                    switch (view.getId()) {
                        case R.id.checkBox2:
                            perfectBurrito = "a veggie burrito with salsa";
                            break;
                        case R.id.checkBox3:
                            perfectBurrito = "a veggie burrito with cheese";
                            break;
                        case R.id.checkBox4:
                            perfectBurrito = "a veggie burrito with sour cream";
                            break;
                        default:
                            perfectBurrito = "a veggie burrito with guac";
                    }
                }
//            } else { //other toggle option
//                if (type_id == R.id.radioButton2) {
//                    if (type_id) {
//                        perfectBurrito = "a meat burrito";
//                    } else {
//                        perfectBurrito = "a meat burrito";
//                    }
                } else {
                    switch (view.getId()) {
                        case R.id.checkBox2:
                            perfectBurrito = "a meat burrito with salsa";
                            break;
                        case R.id.checkBox3:
                            perfectBurrito = "a meat burrito with cheese";
                            break;
                        case R.id.checkBox4:
                            perfectBurrito = "a meat burrito with sour cream";
                            break;
                        default:
                            perfectBurrito = "a meat burrito with guac";
                    }
                }

//            }


            //text view
            TextView burritoSelection = (TextView) findViewById(R.id.textView3);
            burritoSelection.setText(perfectBurrito + " is the burrito for you");
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
