package com.example.zojo1044.workout;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {
    public int difficulty = 1;
    public int type = 1;

    public void set_Difficulty(View view) {
        RadioGroup difficulties = (RadioGroup) findViewById(R.id.difficulty_buttons);
        switch (difficulties.getCheckedRadioButtonId()) {
            case R.id.easy:
                difficulty = 1;
                break;
            case R.id.medium:
                difficulty = 2;
                break;
            case R.id.hard:
                difficulty = 3;
                break;
        }
        System.out.println("difficulty:" + difficulty);
    }

    public void set_type(View view) {
        RadioGroup types = (RadioGroup) findViewById(R.id.type_buttons);
        switch (types.getCheckedRadioButtonId()) {
            case R.id.cardio:
                type = 1;
                break;
            case R.id.yoga:
                type = 2;
                break;
            case R.id.strength:
                type = 3;
                break;
        }
        System.out.println("Type: " + type);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void changeActivity(View view){
        if (type == 1) {
            if (difficulty == 1) {
                Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                startActivity(intent);
            } else if (difficulty == 2) {
                Intent intent = new Intent(MainActivity.this, Main3Activity.class);
                startActivity(intent);
            } else if (difficulty == 3) {
                Intent intent = new Intent(MainActivity.this, Main4Activity.class);
                startActivity(intent);
            }
        } else if (type == 2){
            if (difficulty == 1) {
                Intent intent = new Intent(MainActivity.this, Main5Activity.class);
                startActivity(intent);
            } else if (difficulty == 2) {
                Intent intent = new Intent(MainActivity.this, Main6Activity.class);
                startActivity(intent);
            } else if (difficulty == 3) {
                Intent intent = new Intent(MainActivity.this, Main7Activity.class);
                startActivity(intent);
            }
        } else if (type == 3){
            if (difficulty == 1) {
                Intent intent = new Intent(MainActivity.this, Main8Activity.class);
                startActivity(intent);
            } else if (difficulty == 2) {
                Intent intent = new Intent(MainActivity.this, Main9Activity.class);
                startActivity(intent);
            } else if (difficulty == 3) {
                Intent intent = new Intent(MainActivity.this, Main10Activity.class);
                startActivity(intent);
            }
        }
    }

}
